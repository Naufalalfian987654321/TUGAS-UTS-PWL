<?php
if (isset($_POST["req"])) {
  // (A) PRODUCTS LIST
  $products = [
    1 => [
      "n" => "Buffet 6 Laci Minimalis Modern Kayu Jati ",
      "p" => 345.67,
      "i" => "Nakas 1.jpg"
    ],
    2 => [
      "n" => "Buffet Kayu Jati Minimalis Resma",
      "p" => 234.56,
      "i" => "Nakas 2.jpg"
    ],
    3 => [
      "n" => "Buffet scandinavian stylish",
      "p" => 123.45,
      "i" => "Nakas 3.jpg"
    ],
    4 => [
      "n" => "Lemari Minimalist Modern",
      "p" => 34.56,
      "i" => "Lemari 1.jpg"
    ],
    5 => [
      "n" => "Kursi Modern Swiss",
      "p" => 23.45,
      "i" => "kursi 1.jpg"
    ],
    6 => [
      "n" => "Meja Scandinavian Modern",
      "p" => 12.34,
      "i" => "Meja belajar.jpg"
    ]
  ];

  // (B) HANDLE REQUESTS
  switch ($_POST["req"]) {
    // (B1) INVALID REQUEST
    default: echo "Invalid request"; break;
  
    // (B2) GET PRODUCTS
    case "get":
      echo json_encode($products);
      break;

    // (B3) CHECKOUT
    case "checkout":
      // (B3-1) DATA YOGA
      $cart = json_decode($_POST["cart"], true);
      unset($_POST["req"]);
      unset($_POST["cart"]);

      // (B3-2) SEND VIA EMAIL
      $msg = "";
      foreach ($_POST as $k=>$v) { $msg .= "$k : $v\r\n"; }
      foreach ($cart as $i=>$q) {
        $msg .= sprintf("%u X %s - $%s\r\n",
          $q, $products[$i]["n"], $q * $products[$i]["p"]
        );
      }
      echo mail("admin@site.com", "Order Received", $msg)
        ? "OK" : "Failed to send email";
      break;
  }
}
