<?php 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <link rel="stylesheet" href="style.css">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JEPARA FURNITURE STEAK</title>
    
    <style>
		img {
			width: 20%; /* Mengatur lebar gambar menjadi 50% dari lebar parent */
			height: auto; /* Mengatur tinggi gambar secara otomatis sesuai rasio aspek gambar */
		}       
        footer {
           background-color: green;
           padding: 20px;
        }

	</style>
    

</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Home</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav">
        <a class="nav-link active" aria-current="page" href="#Company_Profile">Company Profile</a>
        <a class="nav-link" href="#produk">About us</a>
        <a class="nav-link" href="2-shop.php">Collection</a>
        <a class="nav-link disabled" href="#location" tabindex="-1" aria-disabled="true">Location</a>
      </div>
    </div>
  </div>
</nav>

<section class="jumbotron text-center" style="position: relative; height: 100vh; overflow: hidden;">
  <video autoplay muted loop poster="poster.jpg" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover;">
    <source src="Video Cinematic Furniture Rayon E.mov" type="video/mp4">
    <source src="video.webm" type="video/webm">
    <source src="video.ogv" type="video/ogg">
  </video>
  <div class="container" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);">
    <h1>JEPARA FURNITURE TEAK</h1>
    <p class="lead">JUAL FURNITURE MINIMALIST BERKUALITAS.</p>
    <a class="btn btn-primary btn-lg" href="2-shop.php" role="button">Liat Semua Produk</a>
  </div>
</section>


<section id="Company_Profile">
        <h1 class="display-4">JEPARA FURNITURE STEAK</h1>
        <p class="lead"><h3>one stop destination for premium quality teak furniture</h3></p>
        <p class="lead">Kami adalah toko furniture teak berkualitas dan terpercaya di Jepara, Indonesia. Produk yang dibuat di Kota Jepara terkenal di Indonesia bahkan Internasional, kami sering melakukan bisnis baik domestik maupun luar negeri. Kami adalah perusahaan keluarga yang telah membuat furniture cantik dan fungsional selama lebih dari 10 tahun. Para seniman berbakat kami menggunakan teknik tradisional dan
             bahan-bahan terbaik untuk menciptakan furniture Jepara yang elegan dan tahan lama.</p>
             <img src="Studio2.jpg" alt="Deskripsi Gambar">  <img src="Studio1.jpg" alt="Deskripsi Gambar"> <img src="sofa-jepara-furnitures-teak-indonesia (1).png" alt="Deskripsi Gambar"><img src="studio4.jpg" alt="Deskripsi Gambar">
        <p class="lead">Di Jepara Furnitures Teak, kami memiliki beragam pilihan furniture untuk dipilih. Apakah Anda mencari set makan klasik atau lounge outdoor modern, kami memiliki sesuatu untuk setiap selera dan anggaran. 
            Koleksi kami mencakup segala sesuatu dari furniture gaya tradisional Indonesia hingga desain kontemporer.</p>
        <p class="lead">Kami bangga dengan komitmen kami terhadap kualitas dan kerajinan. Furniture kami terbuat dari kayu teak yang diolah secara berkelanjutan, yang dikenal karena ketahanannya, kekuatannya, dan resistensi alami terhadap kerusakan dan penurunan. 
            Setiap bagian dibuat dengan perhatian dan perhatian terhadap detail, memastikan bahwa itu akan tahan lama.</p>
        <p class="lead"><h3>Beragam Jenis Furniture Jepara lainnya</h3></p>
        <p class="lead">Kami juga menawarkan berbagai jenis furniture Jepara lain, termasuk rak buku, meja, lemari pakaian, dan lainnya. Perabot kami sempurna untuk setiap ruangan di rumah Anda, termasuk ruang tamu, ruang makan, kamar tidur, dan kantor.</p>
        <p class="lead">Di Jepara Furnitures Teak, kami percaya bahwa kualitas dan kerajinan tidak boleh dikompromikan. Itulah sebabnya kami hanya menggunakan bahan-bahan terbaik dan teknik tradisional untuk menciptakan perabot yang indah dan fungsional. Kami sangat bangga dengan pekerjaan kami dan berkomitmen untuk memberikan pelayanan terbaik kepada pelanggan kami.</p>  
        <p class="lead"><h3>Selamat Datang Di Jepara Furniture Teak</h3></p>
        <p class="lead">Jati Jepara Mebel melayani spesial custom furniture ( anda punya ide, model & design sesuai yang anda inginkan serta ukuran menyesuikan space ruangan anda)</p>
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#fff" fill-opacity="1" d="M0,32L8.6,37.3C17.1,43,34,53,51,85.3C68.6,117,86,171,103,181.3C120,192,137,160,154,128C171.4,96,189,64,206,85.3C222.9,107,240,181,257,208C274.3,235,291,213,309,197.3C325.7,181,343,171,360,165.3C377.1,160,394,160,411,154.7C428.6,149,446,139,463,138.7C480,139,497,149,514,154.7C531.4,160,549,160,566,181.3C582.9,203,600,245,617,234.7C634.3,224,651,160,669,133.3C685.7,107,703,117,720,128C737.1,139,754,149,771,138.7C788.6,128,806,96,823,80C840,64,857,64,874,74.7C891.4,85,909,107,926,112C942.9,117,960,107,977,122.7C994.3,139,1011,181,1029,197.3C1045.7,213,1063,203,1080,192C1097.1,181,1114,171,1131,154.7C1148.6,139,1166,117,1183,117.3C1200,117,1217,139,1234,138.7C1251.4,139,1269,117,1286,101.3C1302.9,85,1320,75,1337,101.3C1354.3,128,1371,192,1389,192C1405.7,192,1423,128,1431,96L1440,64L1440,320L1431.4,320C1422.9,320,1406,320,1389,320C1371.4,320,1354,320,1337,320C1320,320,1303,320,1286,320C1268.6,320,1251,320,1234,320C1217.1,320,1200,320,1183,320C1165.7,320,1149,320,1131,320C1114.3,320,1097,320,1080,320C1062.9,320,1046,320,1029,320C1011.4,320,994,320,977,320C960,320,943,320,926,320C908.6,320,891,320,874,320C857.1,320,840,320,823,320C805.7,320,789,320,771,320C754.3,320,737,320,720,320C702.9,320,686,320,669,320C651.4,320,634,320,617,320C600,320,583,320,566,320C548.6,320,531,320,514,320C497.1,320,480,320,463,320C445.7,320,429,320,411,320C394.3,320,377,320,360,320C342.9,320,326,320,309,320C291.4,320,274,320,257,320C240,320,223,320,206,320C188.6,320,171,320,154,320C137.1,320,120,320,103,320C85.7,320,69,320,51,320C34.3,320,17,320,9,320L0,320Z"></path></svg>
    </section>
    <section id="about">
         <div class="container">
         <div class="row text-center mb-3">
    <div class="col">
        <img src="Studio1.jpg" alt="Deskripsi Gambar"><img src="Studio2.jpg" alt="Deskripsi Gambar"><img src="Studio3.png" alt="Deskripsi Gambar">
        <h2>All Product</h2>
        <a href="2-shop.php" class="button">Keunggulan</a>
    </div>
     </div>
     <section id="location">
            <div class="row justify-content-around text-center fs-5">
                <div class="col-md-4">
                    <p><h3>Jual Furniture Minimalis.</h3></p>
                    <p>berbagai mebel asli jepara berkualitas
                        modern dan stylish
                    </p>
                </div>
                <div class="col-md-4">
                    <p><h3>Location</h3></p>
                    <p>Jln. Kyai Nawawi KM. 02 RT.20 / RW.04 Ngabul Jepara Kab. Jepara Jawa tengah 59452</P>
                </div>
            </div>
        </div>
        
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#f3f4f5" fill-opacity="1" d="M0,224L8.6,202.7C17.1,181,34,139,51,128C68.6,117,86,139,103,160C120,181,137,203,154,176C171.4,149,189,75,206,80C222.9,85,240,171,257,197.3C274.3,224,291,192,309,197.3C325.7,203,343,245,360,240C377.1,235,394,181,411,165.3C428.6,149,446,171,463,165.3C480,160,497,128,514,133.3C531.4,139,549,181,566,197.3C582.9,213,600,203,617,208C634.3,213,651,235,669,240C685.7,245,703,235,720,218.7C737.1,203,754,181,771,186.7C788.6,192,806,224,823,202.7C840,181,857,107,874,85.3C891.4,64,909,96,926,144C942.9,192,960,256,977,282.7C994.3,309,1011,299,1029,282.7C1045.7,267,1063,245,1080,229.3C1097.1,213,1114,203,1131,197.3C1148.6,192,1166,192,1183,213.3C1200,235,1217,277,1234,245.3C1251.4,213,1269,107,1286,96C1302.9,85,1320,171,1337,213.3C1354.3,256,1371,256,1389,224C1405.7,192,1423,128,1431,96L1440,64L1440,320L1431.4,320C1422.9,320,1406,320,1389,320C1371.4,320,1354,320,1337,320C1320,320,1303,320,1286,320C1268.6,320,1251,320,1234,320C1217.1,320,1200,320,1183,320C1165.7,320,1149,320,1131,320C1114.3,320,1097,320,1080,320C1062.9,320,1046,320,1029,320C1011.4,320,994,320,977,320C960,320,943,320,926,320C908.6,320,891,320,874,320C857.1,320,840,320,823,320C805.7,320,789,320,771,320C754.3,320,737,320,720,320C702.9,320,686,320,669,320C651.4,320,634,320,617,320C600,320,583,320,566,320C548.6,320,531,320,514,320C497.1,320,480,320,463,320C445.7,320,429,320,411,320C394.3,320,377,320,360,320C342.9,320,326,320,309,320C291.4,320,274,320,257,320C240,320,223,320,206,320C188.6,320,171,320,154,320C137.1,320,120,320,103,320C85.7,320,69,320,51,320C34.3,320,17,320,9,320L0,320Z"></path></svg>
    </section>
    <section id="produk" style="background-image: url('Studio1.jpg');">
        <div class="container">
            <div class="row text-center mb-3 justify-content-evenly">
                <div class="col">
                    <h2>Produk Unggulan</h2>
                </div>
            </div>
            <div class="row justify-content-around text-center fs-5">
                <div class="col-md-4 mb-3">
                    <div class="card">
                        <img src="Nakas 1.jpg" class="card-img-top">
                        <div class="card-body text-center">
                            <h5 class="card-title">Buffet 4 Laci Minimalis Modern Kayu Jati JJM-BFF 054</h5>
                            <p class="card-text"></p>
                        </div>
                    </div>
                </form>
                </div>
                <div class="col-md-4 mb-3">
                
                    <div class="card text center">
                        <img src="Nakas 2.jpg" class="card-img-top">
                        <div class="card-body text-center">
                            <h5 class="card-title">Buffet 4 Laci Scandinavian Vintage Retro Kayu Jati JJM-BFF 041</h5>
                            <p class="card-text">-</p>
                            
                        </div>
                    </div>
                </form>
                </div>
                <div class="col-md-4 mb-3">
                
                    <div class="card text center">
                        <img src="Nakas 3.jpg" class="card-img-top">
                        <div class="card-body text-center">
                            <h5 class="card-title">Buffet 7 Laci Minimalis Modern Kayu Jati JJM-BFF 044</h5>
                            <p class="card-text">-</p>
                            
                        </div>
                    </div>
                </form>
                </div>
                <div class="col-md-4 mb-3">
                
                    <div class="card text center">
                        <img src="Nakas 4.jpg" class="card-img-top">
                        <div class="card-body text-center">
                            <h5 class="card-title">Buffet Aquarium Minimalis Kayu Jati Ferto</h5>
                            <p class="card-text">-</p>
                           
                        </div>
                    </div>
                </form>
                </div>
                <div class="col-md-4 mb-3">
               
                    <div class="card text center">
                        <img src="Nakas 5.jpg" class="card-img-top">
                        <div class="card-body text-center">
                            <h5 class="card-title">Buffet Credenza With Round Mirror Kayu Jati JJM-BFF 038</h5>
                            <p class="card-text">-</p>
                            
                        </div>
                    </div>
                </form>
                </div>
                <div class="col-md-4 mb-3">
                
                    <div class="card text center">
                        <img src="Nakas 6.jpg" class="card-img-top">
                        <div class="card-body text-center">
                            <h5 class="card-title">Buffet Jati Minimalis Amsterdam</h5>
                            <p class="card-text">-</p>
                        </div>
                    </div>
                </form>
                </div>
                <div class="col-md-4 mb-3">
                
                    <div class="card text center">
                        <img src="Nakas 7.jpg" class="card-img-top">
                        <div class="card-body text-center">
                            <h5 class="card-title">Buffet Jati Scandinavian Mofin</h5>
                            <p class="card-text">-</p>
                            <
                        </div>
                    </div>
                </form>
                </div>
                <div class="col-md-4 mb-3">
                
                    <div class="card text center">
                        <img src="Nakas 8.jpg" class="card-img-top">
                        <div class="card-body text-center">
                            <h5 class="card-title">Buffet Kaca Kayu Jati Minimalis Modern Armando</h5>
                            <p class="card-text">-</p>
                            
                        </div>
                    </div>
                </form>
                </div>
                <div class="col-md-4 mb-3">
                
                    <div class="card text center">
                        <img src="Nakas 9.jpg" class="card-img-top">
                        <div class="card-body text-center">
                            <h5 class="card-title">Buffet Kayu Jati Minimalis Dinasti JJM-BFF 030</h5>
                            <p class="card-text">-</p>
                            
                        </div>
                    </div>
                </form>
                </div>
                <div class="col-md-4 mb-3">
                
                    <div class="card text center">
                        <img src="Nakas 10.jpg" class="card-img-top">
                        <div class="card-body text-center">
                            <h5 class="card-title">Buffet Kayu Jati Minimalis Resma</h5>
                            <p class="card-text">-</p>
                           
                        </div>
                    </div>
                </form>
                </div>
                <div class="col-md-4 mb-3">
               
                    <div class="card text center">
                        <img src="Kursi 1.jpg" class="card-img-top">
                        <div class="card-body text-center">
                            <h5 class="card-title">Kursi Cafe Belvia</h5>
                            <p class="card-text">-</p>
                            
                        </div>
                    </div>
                </form>
                </div>
                <div class="col-md-4 mb-3">
                  <div class="card text center">
                        <img src="Meja belajar.jpg" class="card-img-top">
                        <div class="card-body text-center">
                            <h5 class="card-title">Meja Modern Minimalist</h5>
                            <p class="card-text">-</p>
                            
                        </div>
                    </div>
                </form>
                </div>
                <div class="col-md-4 mb-3">
               
                    <div class="card text center">
                        <img src="Lemari 1.jpg" class="card-img-top">
                        <div class="card-body text-center">
                            <h5 class="card-title">Display Cabinet Minimalis Century</h5>
                            <p class="card-text">-</p>
                            
                        </div>
                    </div>
                </form>
                </div>
            </div>
        </div>
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#fff" fill-opacity="1" d="M0,32L8.6,53.3C17.1,75,34,117,51,154.7C68.6,192,86,224,103,229.3C120,235,137,213,154,197.3C171.4,181,189,171,206,160C222.9,149,240,139,257,165.3C274.3,192,291,256,309,266.7C325.7,277,343,235,360,197.3C377.1,160,394,128,411,133.3C428.6,139,446,181,463,213.3C480,245,497,267,514,256C531.4,245,549,203,566,202.7C582.9,203,600,245,617,245.3C634.3,245,651,203,669,176C685.7,149,703,139,720,160C737.1,181,754,235,771,250.7C788.6,267,806,245,823,245.3C840,245,857,267,874,245.3C891.4,224,909,160,926,122.7C942.9,85,960,75,977,85.3C994.3,96,1011,128,1029,154.7C1045.7,181,1063,203,1080,213.3C1097.1,224,1114,224,1131,218.7C1148.6,213,1166,203,1183,197.3C1200,192,1217,192,1234,176C1251.4,160,1269,128,1286,144C1302.9,160,1320,224,1337,224C1354.3,224,1371,160,1389,149.3C1405.7,139,1423,181,1431,202.7L1440,224L1440,320L1431.4,320C1422.9,320,1406,320,1389,320C1371.4,320,1354,320,1337,320C1320,320,1303,320,1286,320C1268.6,320,1251,320,1234,320C1217.1,320,1200,320,1183,320C1165.7,320,1149,320,1131,320C1114.3,320,1097,320,1080,320C1062.9,320,1046,320,1029,320C1011.4,320,994,320,977,320C960,320,943,320,926,320C908.6,320,891,320,874,320C857.1,320,840,320,823,320C805.7,320,789,320,771,320C754.3,320,737,320,720,320C702.9,320,686,320,669,320C651.4,320,634,320,617,320C600,320,583,320,566,320C548.6,320,531,320,514,320C497.1,320,480,320,463,320C445.7,320,429,320,411,320C394.3,320,377,320,360,320C342.9,320,326,320,309,320C291.4,320,274,320,257,320C240,320,223,320,206,320C188.6,320,171,320,154,320C137.1,320,120,320,103,320C85.7,320,69,320,51,320C34.3,320,17,320,9,320L0,320Z"></path></svg>
        </section>
    
        
            <footer class="footer"> 
               <div class="container">
               <center>
                   <p>Copyright &Jepara Mebel Group. All Rights Reserved. | Contact Us: 085812333811</p>
                   <p>Furniture Minimalist & Ukir | Custom Design Furniture</p>
                   
               </center>
               </div>
           </footer>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

</body>
</html>